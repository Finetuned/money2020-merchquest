# Active Context: MerchQuest

## Current Work Focus
FastAPI backend connected to PostgreSQL. Server verified working locally.

## Recent Changes
- Rewrote `frontend/backend/main.py` — full asyncpg + PostgreSQL integration
- Added `asyncpg` and `python-dotenv` to `frontend/backend/requirements.txt`
- Created `.venv` in `frontend/backend/` with all dependencies installed
- `backend/schema.sql` and `backend/seed.sql` applied to local `merchquest` DB
- All 6 Cline Memory Bank files and Serena memory files reflect correct architecture

## Current State

### What Works
- **`frontend/backend/main.py`**: FastAPI backend connected to PostgreSQL via asyncpg
  - Connection pool created at startup via `lifespan`
  - `DATABASE_URL` from env var (default: `postgresql://julianweaver@localhost:5432/merchquest`)
  - All endpoints migrated from in-memory to DB queries
  - Balance computed dynamically via `user_balances` view
  - Transactions used for checkout and vendor deletion
- **`frontend/www/`**: Customer React app — all routes implemented
- **`frontend/www_vendor/`**: Vendor CMS React app — all routes implemented
- **`frontend/unity/m2020merch/`**: Unity 3D project with API + UI scripts
- **`fastapi/openapi.json`**: OpenAPI 3.1.0 schema
- **`backend/schema.sql`** + **`backend/seed.sql`**: Applied to local DB

### Known Issue: Coin ID Offset
- PostgreSQL SERIAL assigned coin IDs **1–6** (not 0–5 as in original Python code)
- QR codes may encode `coin_id=0` through `coin_id=5`
- If QR codes use 0-based IDs, coin lookups will fail — fix by re-seeding with explicit IDs

## Next Steps
1. **Test end-to-end flows** with the React apps against the local backend
2. **Verify coin ID offset** — check what IDs the QR codes encode; update seed if needed
3. **Deploy to Render** — set `DATABASE_URL` env var pointing to provisioned PostgreSQL
4. **Update CORS** in `main.py` if production domain differs from `ramjam.co.uk`

## Active Decisions & Considerations
- **Balance is computed dynamically**: `user_balances` view — no stored balance column
- **asyncpg connection pool**: created at startup, shared across all requests
- **`.venv`** in `frontend/backend/` — activate with `source .venv/bin/activate` before running
- **Run command**: `cd frontend/backend && .venv/bin/uvicorn main:app --reload`
- `frontend/` is a git submodule — commits MUST be made from inside `frontend/`
- Cookie domain is `localhost` for dev; update `secure=True` and domain for production

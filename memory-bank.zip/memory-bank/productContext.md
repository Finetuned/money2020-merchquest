# Product Context: MerchQuest

## Why This Project Exists
MerchQuest creates a gamified, cashless merchandise experience at the Money2020 event. Attendees collect virtual coins by scanning QR codes placed around the event venue (in a 3D Unity experience), then redeem those coins for branded merchandise at vendor booths — eliminating cash, creating engagement, and providing event analytics.

## Problems It Solves
- **Cashless transactions**: No cash needed at merchandise stands
- **Gamification**: Coin hunting adds an interactive layer to the event
- **Inventory tracking**: Real-time stock management for vendors
- **Fair distribution**: Controlled coin allocation prevents overselling
- **Guest experience**: No account creation required — guest auth via cookie
- **Delegate validation**: Ties event badge (delegateID) to user for eligibility checks

## User Types & Flows

### 1. Attendee (Customer App — `frontend/www/`)
1. Open the customer web app → receive guest session (cookie-based)
2. Validate event delegate badge (scan badge QR or enter delegate ID)
3. Scan QR codes around the venue → collect virtual coins
4. View wallet (coin balance)
5. At vendor booth, present QR code → vendor scans to process checkout
6. Coins deducted; merchandise received

### 2. Vendor (Vendor CMS — `frontend/www_vendor/`)
1. Set up vendor identity (scan vendor QR code to set vendorID)
2. Scan attendee QR code or look up customer
3. View customer coin balance and available items
4. Process redemption (checkout) → deduct coins, update stock
5. View order summary
6. Manage vendor stock (add/update items)

### 3. Admin (via API or Vendor CMS)
1. Add/remove vendors
2. Manage global merchandise catalogue (add/update/delete stock items)
3. Assign stock to vendors
4. View user balances

### 4. Unity Experience
- Attendees interact with a 3D virtual environment where coins are placed at real-world locations
- Coins have a `locationref` (physical location), `value` (coin points), and `glbRef` (3D model file)
- QR codes physically placed at `locationref` locations link to the web app's Scanner route

## UX Goals
- **Mobile-first**: React apps built for phone use at the event
- **Zero friction**: Guest sessions require no signup
- **Fast checkout**: Vendor scans attendee QR → instant redemption
- **Offline-resilient**: In-memory backend during development (DB migration planned)
- **Secure coin data**: `rot47Cipher.js` used to obfuscate coin/user data in QR codes

## Key Technical Experience
- QR codes → `react-qr-barcode-scanner` in both React apps
- 3D coin viewing → GLB model references (via Unity / web viewer)
- Cookie-based guest identity across both apps
- `UserContext` React context provides auth state globally in both apps
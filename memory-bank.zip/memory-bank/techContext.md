# Tech Context: MerchQuest

## Technologies Used

### Customer App (`frontend/www/`)
| Technology | Version | Purpose |
|------------|---------|---------|
| React | 19.2.0 | UI framework (JSX) |
| Vite | 7.2.4 | Build tool & dev server (port 5173) |
| React Router | 7.10.1 | Client-side routing |
| Tailwind CSS | 4.1.18 | Utility-first CSS |
| react-qr-barcode-scanner | 2.1.20 | QR code scanning |
| @radix-ui/react-dialog | 1.1.15 | Modal dialogs |
| @radix-ui/react-slot | 1.2.4 | Composable primitives |
| lucide-react | 0.561.0 | Icons |
| base-64 | 1.0.0 | Base64 encoding for QR payloads |
| ESLint | 9.39.1 | Linting |

### Vendor CMS (`frontend/www_vendor/`)
Same stack as customer app, plus:
| Technology | Version | Purpose |
|------------|---------|---------|
| @radix-ui/react-label | 2.1.8 | Form labels |
| shadcn/ui | - | Component system (components.json) |
| class-variance-authority | 0.7.1 | Component variants |

### Backend (`frontend/backend/`)
| Technology | Purpose |
|------------|---------|
| Python | Language |
| FastAPI | REST API framework |
| Pydantic | Request/response validation |
| uvicorn | ASGI server |
| PostgreSQL | Database (**NOT YET PROVISIONED**) |

### Unity (`frontend/unity/m2020merch/`)
| Technology | Purpose |
|------------|---------|
| Unity (URP) | 3D rendering engine |
| C# | Scripting language |
| Universal Render Pipeline | Mobile-optimised rendering |

### Infrastructure
| Technology | Purpose |
|------------|---------|
| Render.com | FastAPI hosting |
| Git submodules | Multi-repo management |

## Development Setup

### Prerequisites
- Node.js (LTS) + npm
- Python 3.x + pip (for backend development)
- Git (with submodule support)
- Unity Editor (for Unity development)

### Initial Setup
```bash
# Clone with submodules
git clone --recurse-submodules git@github.com:Finetuned/money2020-merchquest.git
cd merchquest

# Or initialize submodules after plain clone
git submodule update --init --recursive

# Install customer app dependencies
cd frontend/www && npm install

# Install vendor app dependencies
cd frontend/www_vendor && npm install

# Install Python backend dependencies
cd frontend/backend && pip install -r requirements.txt
```

### Development Servers
```bash
# Customer app (port 5173)
cd frontend/www && npm run dev

# Vendor CMS (port 5174 — set via vite.config.js)
cd frontend/www_vendor && npm run dev

# Python backend
cd frontend/backend && uvicorn main:app --reload
# OR use start.sh in frontend root
```

### Environment Variables
Both React apps use `.env.development` and `.env.production`:
- `VITE_API_URL` — FastAPI base URL
  - Dev: `http://localhost:8000` (or similar)
  - Prod: `https://money2020-merchquest.onrender.com`

## Technical Constraints

1. **No TypeScript**: Both React apps use plain JSX (`.jsx`), not TSX
2. **Database not provisioned**: PostgreSQL backend not yet connected; `frontend/backend/main.py` uses in-memory Python dicts
3. **Git submodule**: All code in `frontend/` is in a separate repo (`danhodgkins/money2020_MerchQuest`); commits MUST be made from within `frontend/`, then parent repo updated
4. **CORS origins**: Backend only allows `localhost:5173`, `localhost:5174`, `ramjam.co.uk`
5. **Cookie auth**: Both apps use `credentials: 'include'` — ensure CORS `allow_credentials=True`
6. **Tailwind v4**: Uses `@tailwindcss/vite` plugin approach (not PostCSS config of v3)

## Key Config Files
- `frontend/www/package.json` — customer app dependencies/scripts
- `frontend/www_vendor/package.json` — vendor app dependencies/scripts
- `frontend/www/jsconfig.json` — JS aliases (`@/` → `src/`)
- `frontend/www_vendor/jsconfig.json` — JS aliases
- `frontend/www/.env.development` + `.env.production` — API URL config
- `frontend/backend/requirements.txt` — Python dependencies
- `fastapi/openapi.json` — API contract (source of truth for endpoints)
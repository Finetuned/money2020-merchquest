# Project Brief: MerchQuest

## Overview
MerchQuest is a merchandise management and virtual currency platform for the Money2020 event. Attendees collect virtual coins (via QR codes in a 3D Unity experience), manage their wallet via a React web app, and redeem coins for merchandise at vendor booths. Vendors manage their stock and process redemptions via a separate CMS React app.

## Repository Structure
```
merchquest/                          # Root repo (git@github.com:Finetuned/money2020-merchquest.git)
├── fastapi/
│   └── openapi.json                 # OpenAPI 3.1.0 schema — source of truth for all API endpoints
├── backend/                         # Empty placeholder directory
└── frontend/                        # Git submodule (danhodgkins/money2020_MerchQuest)
    ├── backend/
    │   ├── main.py                  # FastAPI Python backend (currently in-memory, no DB yet)
    │   └── requirements.txt
    ├── qr_codes/                    # QR code PNGs for coins 0–2
    ├── unity/m2020merch/            # Unity 3D project (C#, URP) — coin collection environment
    ├── www/                         # Customer-facing React app (attendees)
    └── www_vendor/                  # Vendor CMS React app
```

## Core Requirements

### Backend API (FastAPI/Python)
- FastAPI REST API hosted on Render at https://money2020-merchquest.onrender.com
- PostgreSQL database — **NOT YET PROVISIONED** (currently in-memory)
- OpenAPI 3.1.0 specification: `fastapi/openapi.json`

### Customer App (`frontend/www/`)
- Guest authentication via cookie-based session
- QR code scanning to collect virtual coins
- Wallet view showing coin balance
- Delegate badge validation system
- View collectible items in 3D (GLB models)

### Vendor CMS (`frontend/www_vendor/`)
- Vendor identity setup (set vendor ID via QR scan)
- Browse and manage vendor list (add/delete vendors)
- Stock management (update inventory)
- Coin redemption flow (scan attendee QR, process checkout)
- Order summary view

### Unity Project (`frontend/unity/m2020merch/`)
- 3D virtual coin collection environment (URP, mobile-optimised)
- API integration (C# scripts in `Assets/Scripts/API/`)
- Delegate UI system (`Assets/Scripts/DelegateUI/`)

## Key Domain Concepts
- **Coins**: Collectible virtual items with a location reference, value, and 3D GLB model reference
- **Balance**: Accumulated coin value for a user
- **Delegate**: Event badge/attendee identifier used for validation
- **Vendors**: Merchandise booths at the event
- **Merch Stock**: Global catalogue of purchasable items (id, price, stock_remaining)
- **Vendor Stock**: Per-vendor item availability
- **Checkout**: Redemption of coins for merchandise at a vendor booth

## Hosted API
- **Base URL**: https://money2020-merchquest.onrender.com
- **Health**: GET /api/health

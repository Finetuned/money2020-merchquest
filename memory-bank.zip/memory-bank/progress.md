# Progress: MerchQuest

## What Works

### Infrastructure
- ✅ Root repository initialized with git submodule (`frontend/`)
- ✅ FastAPI backend deployed on Render at https://money2020-merchquest.onrender.com
- ✅ OpenAPI schema available at `fastapi/openapi.json`
- ✅ Serena MCP activated at project root
- ✅ Cline Memory Bank initialized (all 6 core files)

### Backend (`frontend/backend/`)
- ✅ `main.py` fully rewritten with asyncpg + PostgreSQL
- ✅ Connection pool via FastAPI `lifespan`
- ✅ `DATABASE_URL` from env var (default: `postgresql://julianweaver@localhost:5432/merchquest`)
- ✅ All endpoints migrated from in-memory to DB queries
- ✅ Balance computed dynamically via `user_balances` view
- ✅ Transactions used for checkout and vendor deletion
- ✅ `.venv` created with all dependencies installed
- ✅ Server verified: starts cleanly, connects to DB, returns coins from PostgreSQL

### Database
- ✅ `backend/schema.sql` — 7 tables + `user_balances` view applied to local DB
- ✅ `backend/seed.sql` — 6 coins seeded (IDs 1–6)
- ✅ Merch stock seeded: t-shirt, hat, hoody, socks, vest (price 1, stock 100 each)

### Customer App (`frontend/www/`)
- ✅ Full React app with all routes: Home, Wallet, Scanner (QR), Collect, Award, DelegateStatus, ViewItem
- ✅ QR code scanning, guest auth, UserContext, rot47Cipher, api.js

### Vendor CMS (`frontend/www_vendor/`)
- ✅ Full React app with all routes: Home, SetVendorID, Scanner, RedeemCoins, OrderSummary, AddVendor, DeleteVendor, UpdateStock, UpdateVendorStock

### Unity Project (`frontend/unity/m2020merch/`)
- ✅ URP project with API scripts, DelegateUI, MerchAssistantUI (SplashPanelController)
- ✅ BaseUIPanel base class + UIPanelContainer

### QR Codes
- ✅ QR code PNGs for coins 0, 1, 2 (`frontend/qr_codes/`)

## What's Left to Build

### Testing
- [ ] End-to-end test: guest auth → coin collection → balance check
- [ ] End-to-end test: vendor setup → stock assignment → checkout → order summary
- [ ] ⚠️ **Verify coin ID offset**: DB coins are IDs 1–6; QR codes may encode 0–5. If mismatch, re-seed with explicit 0-based IDs

### Deployment
- [ ] Provision PostgreSQL on Render (or Neon/Supabase)
- [ ] Set `DATABASE_URL` env var on Render
- [ ] Redeploy FastAPI to Render with DB connection
- [ ] Update cookie `domain` and `secure=True` for production HTTPS
- [ ] Update CORS origins if production domain differs from `ramjam.co.uk`

### Unity
- [ ] Verify Unity API scripts connect to hosted FastAPI
- [ ] Test delegate validation flow from Unity

## Current Status
**Phase**: Backend DB integration complete locally; ready for end-to-end testing and production deployment

## Known Issues
1. **Coin ID offset**: PostgreSQL SERIAL assigned IDs 1–6; original Python code used 0–5. QR codes may encode 0-based IDs — verify before going live
2. **Cookie domain**: `main.py` sets `domain="localhost"` — must be updated for production
3. **CORS**: Only allows `localhost:5173`, `localhost:5174`, `ramjam.co.uk` — add production domains as needed
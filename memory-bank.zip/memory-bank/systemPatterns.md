# System Patterns: MerchQuest

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                          Client Layer                                │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌───────────┐ │
│  │ Customer App         │  │ Vendor CMS            │  │  Unity    │ │
│  │ frontend/www/        │  │ frontend/www_vendor/  │  │  App      │ │
│  │ :5173 (dev)          │  │ :5174 (dev)           │  │           │ │
│  └──────────┬───────────┘  └──────────┬────────────┘  └─────┬─────┘ │
└─────────────┼──────────────────────────┼──────────────────── ┼──────┘
              │ HTTP/REST (cookie auth)   │                     │
              ▼                          ▼                      ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     FastAPI Backend                                  │
│            https://money2020-merchquest.onrender.com                 │
│            frontend/backend/main.py (in-memory currently)           │
│            OpenAPI schema: fastapi/openapi.json                      │
└─────────────────────────────┬───────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│              PostgreSQL Database (NOT YET PROVISIONED)               │
└─────────────────────────────────────────────────────────────────────┘
```

## Frontend Architecture (Both React Apps Share These Patterns)

### File Structure Pattern
```
frontend/www/src/               frontend/www_vendor/src/
├── api.js                      ├── api.js
├── App.jsx                     ├── App.jsx
├── main.jsx                    ├── main.jsx
├── context/UserContext.jsx     ├── context/UserContext.jsx
├── lib/
│   ├── rot47Cipher.js          │   ├── rot47Cipher.js
│   └── utils.js (vendor only) │   └── utils.js
├── components/
│   ├── ui/                     │   ├── ui/
│   ├── Navigation/             │   ├── Navigation/
│   ├── AwardCoin/              │   ├── AwardCoin/
│   └── CoinsManager/           │   └── CoinsManager/
└── routes/                     └── routes/
    (customer routes)               (vendor routes)
```

### Shared Patterns Across Both Apps

#### 1. API Client (`api.js`)
- Centralised API call module
- Uses `fetch()` with `credentials: 'include'` for cookie-based auth
- Base URL from environment variable (`import.meta.env.VITE_API_URL`)

#### 2. User Context (`context/UserContext.jsx`)
- React Context for global auth state
- Wraps the entire app
- Stores guest user identity from cookie

#### 3. rot47 Cipher (`lib/rot47Cipher.js`)
- Data obfuscation for QR code payloads
- Prevents casual reading of coin/user data encoded in QR codes

#### 4. Component Pattern
Named arrow function with default export:
```jsx
const MyComponent = () => {
  return <div>...</div>
}
export default MyComponent
```

#### 5. Routing
React Router 7 nested routes with `RootLayout` providing shell + `<Outlet />`

### Import Aliases
- `@/` maps to `src/` (configured in `jsconfig.json`)

## Customer App Routes (`frontend/www/`)
| Route | Purpose |
|-------|---------|
| Home | Landing page |
| Wallet | View coin balance |
| Scanner | QR code scanner to collect coins |
| Collect | Coin collection confirmation |
| Award | Award coins to a user |
| DelegateStatus | Check/validate event badge delegate status |
| ViewItem | View a collectible coin item in 3D |

## Vendor CMS Routes (`frontend/www_vendor/`)
| Route | Purpose |
|-------|---------|
| Home | Vendor dashboard |
| SetVendorID | Scan QR to set vendor identity |
| Scanner | Scan attendee QR code |
| RedeemCoins | Process coin redemption / checkout |
| OrderSummary | View completed order |
| AddVendor | Add new vendor |
| DeleteVendor | Remove a vendor |
| UpdateStock | Update global merchandise stock |
| UpdateVendorStock | Update vendor-specific stock |

## Authentication Pattern
- Guest sessions: POST `/api/auth/guest` sets a `guest_user_id` cookie
- Subsequent requests pass cookie automatically (`credentials: 'include'`)
- No JWT tokens or Authorization headers — pure cookie-based sessions
- `delegateID` validation is a separate flow layered on top of guest auth

## QR Code Data Flow
1. Physical QR code placed at event location (see `frontend/qr_codes/`)
2. QR encodes a rot47-obfuscated payload with coin/user ID
3. User scans QR via the Scanner route in customer app
4. App decodes payload → calls API to register coin collection

## Backend Patterns (Python/FastAPI)
- Pydantic models for request validation
- Cookie parameter for `guest_user_id` on protected endpoints
- CORS configured for `localhost:5173`, `localhost:5174`, `ramjam.co.uk`
- Currently uses Python dicts for in-memory storage (to be replaced with PostgreSQL)